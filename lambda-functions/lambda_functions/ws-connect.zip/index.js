const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    console.log("NEW EVENT")
    console.log(event)
    const {
        requestContext: { connectionId, routeKey },
    } = event;
    
    await dynamo.put({
        TableName: "connections",
        Item: {
            id: "store",
            connectionId
        }
    }).promise()
    
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
