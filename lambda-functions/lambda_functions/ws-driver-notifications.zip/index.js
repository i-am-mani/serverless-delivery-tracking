const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

const apig = new AWS.ApiGatewayManagementApi({
    endpoint: "cw5fyyni88.execute-api.ap-south-1.amazonaws.com/production",
});

exports.handler = async(event) => {
    console.log("NEW EVENT")
    console.log(event)
    const {
        requestContext: { connectionId, routeKey },
    } = event;

    if (routeKey === "$connect") {
        const res = await dynamo.put({
            TableName: 'ws-connections',
            Item: { collectionId: "driver-notifications", connectionId: connectionId },
        }).promise()

        const response = {
            statusCode: 200,
            body: JSON.stringify(res),
        };
        return response;
    }

    if (routeKey === "$disconnect") {
        const res = await dynamo.delete({
            TableName: 'ws-connections',
            Key: { connectionId: connectionId }
        }).promise()

        const response = {
            statusCode: 200,
            body: JSON.stringify(res),
        };
        return response;
    }

    if (routeKey == "$default") {
        let json = JSON.parse(event.body);

        const body = await dynamo
            .scan({
                TableName: "notifications",
            })
            .promise();

        await apig
            .postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({ action: "default", items: body.Items }),
            })
            .promise();

        return {
            statusCode: 200,
        }
    }

};
