const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

const apig = new AWS.ApiGatewayManagementApi({
    endpoint: "cw5fyyni88.execute-api.ap-south-1.amazonaws.com/production/",
});

function dispatchChange(conId, body) {
    return apig
        .postToConnection({
            ConnectionId: conId,
            Data: JSON.stringify(body),
        })
        .promise();
}

/**
 *  Broadcast New Notification and Removed Notifications.
**/
exports.handler = async(event) => {
    console.log("NEW EVENT-1")
    console.log(event)
    const record = event.Records[0]


    if (record.eventName === "INSERT") {
        const data = record.dynamodb
        const notificationid = data.Keys.id.S

        const connections = await dynamo.query({
            TableName: "ws-connections",
            IndexName: "collectionIdIndex",
            KeyConditionExpression: "collectionId = :value",
            ExpressionAttributeValues: {
                ":value": "driver-notifications"
            },
        }).promise()
        
        const notification = await dynamo.get({
            TableName: "notifications",
            Key: {
                id: notificationid
            }
        }).promise()

        if (connections.Items.length > 0) {

            const ids = connections.Items.map(item => {
                return item.connectionId
            })

            const promises = ids.map((id) => {
                return dispatchChange(id, { action: "INSERT", data: notification.Item })
            })

            await Promise.all(promises)
        }
    }


    if (record.eventName === "REMOVE") {
        const data = record.dynamodb
        const notificationid = data.Keys.id.S

        const connections = await dynamo.query({
            TableName: "ws-connections",
            IndexName: "collectionIdIndex",
            KeyConditionExpression: "collectionId = :value",
            ExpressionAttributeValues: {
                ":value": "driver-notifications"
            },
        }).promise()

        if (connections.Items.length > 0) {

            const ids = connections.Items.map(item => {
                return item.connectionId
            })

            const promises = ids.map((id) => {
                return dispatchChange(id, { action: "DELETE", id: notificationid })
            })

            await Promise.all(promises)
        }
    }

    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
