const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

const apig = new AWS.ApiGatewayManagementApi({
    endpoint: "hbvhy417vf.execute-api.ap-south-1.amazonaws.com/production",
});

function dispatchChange(conId, body) {
    return apig
        .postToConnection({
            ConnectionId: conId,
            Data: JSON.stringify(body),
        })
        .promise();
}

exports.handler = async(event) => {
    console.log("NEW EVENT-1")
    console.log(event)
    const record = event.Records[0]

    if (record.eventName === "MODIFY") {
        const data = record.dynamodb

        const connections = await dynamo.query({
            TableName: "ws-connections",
            IndexName: "collectionIdIndex",
            KeyConditionExpression: "collectionId = :value",
            ExpressionAttributeValues: {
                ":value": data.Keys.id.S
            },
        }).promise()
        
        const newStoreData = await dynamo.get({
            TableName: "stores",
            Key: {
                id: data.Keys.id.S
            }
        }).promise()

        if (connections.Items.length > 0) {

            const ids = connections.Items.map(item => {
                return item.connectionId
            })

            const promises = ids.map((id) => {
                return dispatchChange(id, newStoreData.Item)
            })

            await Promise.all(promises)
        }
    }

    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
