const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async(event) => {
    let requestJSON ;

    if (event.routeKey === "POST /orders") {
        requestJSON = JSON.parse(event.body)
        const order = requestJSON.order
        const notification = requestJSON.notification


        // CREATE NEW ORDER
        await dynamo.put({
            TableName: 'orders',
            Item: { ...order }
        }).promise()
        
        // Append Order id to Customer Orders
        await dynamo.update({
            TableName: 'customers',
            Key: {
                id: order.customerId
            },
            UpdateExpression: "ADD orderIds :orderIds",
            ExpressionAttributeValues: {
                ":orderIds": dynamo.createSet([order.id])
            }
        }).promise()

        // PUSH NOTIFICATION
        await dynamo.put({
            TableName: 'notifications',
            Item: { ...notification }
        }).promise()


        // DEDUCT STORE PRODUCTS STOCK
        const orderItems = order.items
        const storeId = order.storeId

        const store = await dynamo.get({
            TableName: 'stores',
            Key: {
                id: storeId
            }
        }).promise()
        
        const storeItems = store.Item.products

        orderItems.forEach((orderItem) => {
            const storeItem = storeItems.find((si) => si.product.id === orderItem.product.id)
            storeItem.stock -= orderItem.qty
        })

        await dynamo.update({
            TableName: 'stores',
            Key: {
                id: storeId
            },
            UpdateExpression: "set products = :updatedProducts",
            ExpressionAttributeValues: {
                ":updatedProducts": storeItems
            }
        }).promise()

    }
    
    else if(event.routeKey === "GET /orders/{id}") {
        // Return Order Item
        const id = event.pathParameters.id
        
        const response = await dynamo.get({
            TableName: "orders",
            Key: {
                id: id
            }
        }).promise()
        
        return {
            statusCode: 200,
            body: JSON.stringify(response.Item)
        }
    }
    
    else if (event.routeKey === "PUT /orders") {
        requestJSON = JSON.parse(event.body)
        // Update location
        const location = requestJSON.location
        const orderId = requestJSON.orderId

        await dynamo.update({
            TableName: "orders",
            Key: {
                id: orderId
            },
            UpdateExpression: "set currentLocation = :latlng",
            ExpressionAttributeValues: {
                ":latlng": location
            }
        }).promise()
    }


    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
