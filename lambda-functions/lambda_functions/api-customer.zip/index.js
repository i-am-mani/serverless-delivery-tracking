const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "DELETE /customers/{id}":
        await dynamo
          .delete({
            TableName: "customers",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `Deleted customer ${event.pathParameters.id}`;
        break;
      case "GET /customers/{id}":
        body = await dynamo
          .get({
            TableName: "customers",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        break;
      case "GET /customers":
        body = await dynamo.scan({ TableName: "customers" }).promise();
        break;
      case "POST /customers":
        let requestJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: "customers",
            Item: {
              id: requestJSON.id,
              location: requestJSON.location,
              orderIds: [],
            }
          })
          .promise();
        body = `Customer ${requestJSON.id} Created`;
        break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};
