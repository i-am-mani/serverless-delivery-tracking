const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async(event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "DELETE /stores/{id}":
        await dynamo
          .delete({
            TableName: "stores",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `Deleted store ${event.pathParameters.id}`;
        break;
      case "GET /stores/{id}":
        body = await dynamo
          .get({
            TableName: "stores",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        break;
      case "GET /stores":
        body = await dynamo.scan({ TableName: "stores" }).promise();
        break;
      case "POST /stores":
        let requestJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: "stores",
            Item: {
              id: requestJSON.id,
              location: requestJSON.location,
              products: requestJSON.products
            }
          })
          .promise();
        body = `Driver ${requestJSON.id} Created`;
        break;

      case "PUT /stores/{id}":
        let updateJSON = JSON.parse(event.body);
        const id = event.pathParameters.id
        await dynamo
          .update({
            TableName: "stores",
            Key: { id: id },
            UpdateExpression: "set products=:products",
            ExpressionAttributeValues: {
              ":products": updateJSON.products,
            },
            ReturnValues: "UPDATED_NEW"
          })
          .promise();
        body = `Driver ${updateJSON.id} Updated`;
        break;

      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  }
  catch (err) {
    statusCode = 400;
    body = err.message;
  }
  finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};
