const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async(event, context) => {
  let body;
  let requestJSON;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "DELETE /drivers/{id}":
        await dynamo
          .delete({
            TableName: "drivers",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `Deleted driver ${event.pathParameters.id}`;
        break;
      case "GET /drivers/{id}":
        body = await dynamo
          .get({
            TableName: "drivers",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        break;
      case "GET /drivers":
        body = await dynamo.scan({ TableName: "drivers" }).promise();
        break;
      case "POST /drivers":
        requestJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: "drivers",
            Item: {
              id: requestJSON.id,
              currentLocation: requestJSON.location,
              orderIds: [],
              activeOrderId: null,
            }
          })
          .promise();
        body = `Driver ${requestJSON.id} Created`;
        break;
      case "PUT /drivers/{id}":
        requestJSON = JSON.parse(event.body);
        // Update Driver Location
        const location = requestJSON.location
        const driverid = requestJSON.driverId

        await dynamo.update({
          TableName: "drivers",
          Key: {
            id: driverid
          },
          UpdateExpression: "set currentLocation = :loc",
          ExpressionAttributeValues: {
            ":loc": location
          }
        }).promise()
        body = "Location Updated"
        break

      case "POST /drivers/accept-order":
        requestJSON = JSON.parse(event.body);
        // Accept Order - Delete notification, set DriverId on Order, activeOrderId on Driver
        const notifId = requestJSON.notificationId;
        const driverId = requestJSON.driverId;
        const orderId = requestJSON.orderId;
        const driverLocation = requestJSON.driverLocation;

        await dynamo.delete({
          TableName: "notifications",
          Key: {
            id: notifId
          }
        }).promise();
        console.log("Notification Deleted");

        await dynamo.update({
          TableName: "orders",
          Key: {
            id: orderId
          },
          UpdateExpression: "set driverId = :driverId, currentLocation = :location",
          ExpressionAttributeValues: {
            ":driverId": driverId,
            ":location": driverLocation
          }
        }).promise();

        await dynamo.update({
          TableName: "drivers",
          Key: {
            id: driverId
          },
          UpdateExpression: "set activeOrderId = :orderId",
          ExpressionAttributeValues: {
            ":orderId": orderId
          }
        }).promise();
        // Ingnore Driver Orders for now - 16-11-2021
        break;

      case "POST /drivers/order-delivered":
        requestJSON = JSON.parse(event.body);
        // Mark Order Delivered
        const did = requestJSON.driverId;
        const oid = requestJSON.orderId;

        await dynamo.update({
          TableName: "orders",
          Key: {
            id: oid
          },
          UpdateExpression: "set deliveryStatus = :sts",
          ExpressionAttributeValues: {
            ":sts": "delivered",
          }
        }).promise()

        await dynamo.update({
          TableName: "drivers",
          Key: {
            id: did
          },
          UpdateExpression: "set activeOrderId = :orderId",
          ExpressionAttributeValues: {
            ":orderId": null,
          }
        }).promise()
        break

      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  }
  catch (err) {
    statusCode = 400;
    body = err.message;
  }
  finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};
